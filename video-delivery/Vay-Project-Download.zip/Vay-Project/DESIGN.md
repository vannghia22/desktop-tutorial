# Visual direction
## Style Prompt
Vietnamese social financial-service talking-head edit. Preserve original speaker, pacing and factual context. White bold captions with selective warm yellow keywords; compact typography and restrained pop entrances. Preserve the warm location and skin tones. Fullscreen motion graphics only for verified spoken points.
## Colors
- #FFFFFF: primary captions
- #FFD447: emphasis
- #151715: caption backing and graphic canvas
- #BDB9AF: secondary labels
## Typography
Be Vietnam Pro, bold 800 and light 300. Use horizontal squeeze sparingly on display headings, never at the expense of Vietnamese accents.
## Motion
Punch-ins 1.10–1.15 around the speaker, 2–4 second visual rhythm; short 120–220ms caption entrances. No speed changes. Safe horizontal margins 100px; captions above platform UI and below face.
## What NOT to Do
- No invented financial benefits, eligibility, rates, fees or approval guarantees.
- No bleep before precise word alignment.
- No stock footage implying verified results or affiliation.
- No unverified subtitles or fabricated contact details.
