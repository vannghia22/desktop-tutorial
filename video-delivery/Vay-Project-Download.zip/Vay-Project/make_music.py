import wave,math,array
sr=24000;dur=44.566667
out=array.array('h')
chords=[(130.81,164.81,196),(110,130.81,164.81),(87.31,110,130.81),(98,123.47,146.83)]
for i in range(int(sr*dur)):
 t=i/sr; c=chords[int(t/4)%4]; fade=min(1,t/1.5,(dur-t)/1.5)
 v=sum(math.sin(2*math.pi*f*t)*.018 for f in c)*fade
 beat=t%.5;v+=math.sin(2*math.pi*(65*beat+1.5*(1-math.exp(-beat*20))))*math.exp(-beat*28)*.025*fade
 for start in (.18,39.1):
  dt=t-start
  if 0<dt<.13:v+=math.sin(2*math.pi*(750*dt+1800*dt*dt))*math.exp(-dt*38)*.035
 out.append(int(max(-1,min(1,v))*32767))
with wave.open('bed.wav','wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes(out.tobytes())
